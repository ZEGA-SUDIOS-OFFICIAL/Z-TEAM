py -3.11 -m venv venv
./venv/Scripts/Activate.ps1
py -m pip install PyQt6 requests python-dotenv
py -m main